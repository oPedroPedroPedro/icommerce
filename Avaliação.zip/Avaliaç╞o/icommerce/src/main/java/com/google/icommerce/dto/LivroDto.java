package com.google.icommerce.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

public class LivroDto {
    
    private String id;
    private Integer codigo;
    @NotBlank(message = "O nome do livro deve ser informado!")
    private String nome;
    @NotNull(message = "O gênero deve ser informado!")
    private String genero;
    @NotBlank(message = "O autor deve ser informado!")
    @Size(min = 3, message = "O nome do autor deve possuir 3 caracteres ou mais!")
    private String autor;
    @Positive
    @NotNull(message = "O valor deve ser informado!")
    private Double valor;
    @Positive
    private Integer quantidadeVendida;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public Integer getCodigo() {
        return codigo;
    }
    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getGenero() {
        return genero;
    }
    public void setGenero(String genero) {
        this.genero = genero;
    }
    public String getAutor() {
        return autor;
    }
    public void setAutor(String autor) {
        this.autor = autor;
    }
    public Double getValor() {
        return valor;
    }
    public void setValor(Double valor) {
        this.valor = valor;
    }
    public Integer getQuantidadeVendida() {
        return quantidadeVendida;
    }
    public void setQuantidadeVendida(Integer quantidadeVendida) {
        this.quantidadeVendida = quantidadeVendida;
    }
    
}
