package com.google.icommerce.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.google.icommerce.model.Livro;

public interface LivroRepository extends MongoRepository<Livro, String>{

    Optional<Livro> findByCodigo(Integer codigo);

    Livro findByNome(String nome);
    
}
