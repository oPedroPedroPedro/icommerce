package com.google.icommerce.service;

import java.util.List;

import com.google.icommerce.dto.LivroDto;

public interface LivroService {

    List<LivroDto> obterTodosOsLivros();
    LivroDto obterPorId(String id);
    LivroDto obterPorCodigo(Integer codigo);
    LivroDto obterPorNome(String nome);
    LivroDto cadastrarLivro(LivroDto livro);
    void deletarLivro(String id);
    LivroDto alterarLivro(String id, LivroDto livro);

}
