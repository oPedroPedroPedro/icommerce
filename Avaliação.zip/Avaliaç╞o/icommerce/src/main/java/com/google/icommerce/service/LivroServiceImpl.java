package com.google.icommerce.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.icommerce.dto.LivroDto;
import com.google.icommerce.model.Livro;
import com.google.icommerce.repository.LivroRepository;

@Service
public class LivroServiceImpl implements LivroService {

    @Autowired
    private LivroRepository repository;

    private ModelMapper mapper = new ModelMapper();

    @Override
    public List<LivroDto> obterTodosOsLivros() {
        List<Livro> livros = repository.findAll();

        return livros.stream()
        .map(l -> mapper.map(l, LivroDto.class))
        .collect(Collectors.toList());

    }

    @Override
    public LivroDto obterPorId(String id){
        Optional<Livro> livro = repository.findById(id);

        if (livro.isPresent()){
            return mapper.map(livro.get(), LivroDto.class);
        }
        return null;
    }

    @Override
    public LivroDto obterPorCodigo(Integer codigo){
        Optional<Livro> livro = repository.findByCodigo(codigo);

        return mapper.map(livro.get(), LivroDto.class);
    }

    @Override
    public LivroDto obterPorNome(String nome){
        Livro livro = repository.findByNome(nome);
        return mapper.map(livro, LivroDto.class);
    }

    @Override
    public LivroDto cadastrarLivro(LivroDto livro){
        Livro livroSalvar = mapper.map(livro, Livro.class);
        repository.save(livroSalvar);
        return mapper.map(livroSalvar, LivroDto.class);
    }

    @Override
    public void deletarLivro(String id){
        repository.deleteById(id);
    }

    @Override
    public LivroDto alterarLivro(String id, LivroDto livro) {
        Optional<Livro>livroBusca = repository.findById(id);

        if (livroBusca.isPresent()) {
            Livro livroAlterar = mapper.map(livro, Livro.class);
            livroAlterar.setId(id);
            livroAlterar = repository.save(livroAlterar);
            return mapper.map(livroAlterar, LivroDto.class);            
        }
        return null;
    }
}