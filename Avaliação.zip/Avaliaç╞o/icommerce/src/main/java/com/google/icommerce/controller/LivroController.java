package com.google.icommerce.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.icommerce.dto.LivroDto;
import com.google.icommerce.service.LivroService;

@RestController
@RequestMapping("/livros")
public class LivroController {
    @Autowired
    private LivroService service;

    @GetMapping
    public List<LivroDto> obterLivros(){
        return service.obterTodosOsLivros();
    }

    @GetMapping("/{id}")
    public LivroDto obterLivroPorId(@PathVariable String id){
        return service.obterPorId(id);
    }

    @GetMapping("/codigo/{codigo}")
    public LivroDto obterLivroPorCodigo(@PathVariable Integer codigo){
        return service.obterPorCodigo(codigo);
    }

    @GetMapping("/nome/{nome}")
    public LivroDto obterLivroPorNome(@PathVariable String nome){
        return service.obterPorNome(nome);
    }

    @GetMapping("/porta")
    public String retornaPorta(@Value("${local.server.port}") String porta){
    return String.format("Microsserviço atuando na porta %s", porta);
    }

    @PostMapping
    public ResponseEntity<LivroDto> cadastrarLivro(@RequestBody @Valid LivroDto livro){
        return new ResponseEntity<>(service.cadastrarLivro(livro), HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public LivroDto alterarLivro(@PathVariable String id, @RequestBody LivroDto livroAlterar) {
        return service.alterarLivro(id, livroAlterar);
    }

    @DeleteMapping("/{id}")
    public void deletarLivro(@PathVariable String id) {
        service.deletarLivro(id);
    } 

}
