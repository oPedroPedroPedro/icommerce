package com.google.payments.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import com.google.payments.model.Pagamento;

public interface PagamentoRepository extends MongoRepository<Pagamento, String>{
    
}
