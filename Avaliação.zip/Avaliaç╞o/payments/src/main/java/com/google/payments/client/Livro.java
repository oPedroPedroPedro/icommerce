package com.google.payments.client;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Livro {
    @NotBlank(message = "O nome do livro deve ser informado!")
    private String nome;
    @NotNull(message = "O gênero deve ser informado!")
    private String genero;
    @NotBlank(message = "O autor deve ser informado!")
    @Size(min = 3, message = "O nome do autor deve possuir 3 caracteres ou mais!")
    private String autor;
    
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getGenero() {
        return genero;
    }
    public void setGenero(String genero) {
        this.genero = genero;
    }
    public String getAutor() {
        return autor;
    }
    public void setAutor(String autor) {
        this.autor = autor;
    }
}
