package com.google.payments.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.google.payments.dto.PagamentoDto;
import com.google.payments.dto.PagamentoDtoComLivro;
import com.google.payments.service.PagamentoService;

@RestController
@RequestMapping("/pagamentos")
public class PagamentoController {
    
    @Autowired
    private PagamentoService service;

    @GetMapping
    public List<PagamentoDto> obterPagamentos(){
        return service.obterTodosOsPagamentos();
      
    }

    @GetMapping("/{id}")
    public PagamentoDtoComLivro obterPagamentosPorId(@PathVariable String id){
        return service.obterPorId(id);
    }


    @GetMapping("/porta")
    public String retornaPorta(@Value("${local.server.port}") String porta){
    return String.format("Microsserviço atuando na porta %s", porta);
    }

    @PostMapping
    public ResponseEntity<PagamentoDto> cadastrarPagamento(@RequestBody @Valid PagamentoDto pagamento){
        return new ResponseEntity<>(service.cadastrarPagamento(pagamento), HttpStatus.CREATED);

    } 

    @PutMapping("/{id}")
    public PagamentoDto alterarPagamento(@PathVariable String id, @RequestBody PagamentoDto pagamentoAlterar){
        return service.alterarPagamento(id, pagamentoAlterar);
    }

    @DeleteMapping("/{id}")
    public void excluirPagamento(@PathVariable String id){
        service.excluirPagamento(id);
    }
}
