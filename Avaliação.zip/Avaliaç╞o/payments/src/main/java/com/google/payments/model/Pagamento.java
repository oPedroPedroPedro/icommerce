package com.google.payments.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document("pagamentos")
public class Pagamento {
    @Id
    private String id;
    private Double valorPago;
    private String livro;
    private FormaPagamento pagamento;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public Double getValorPago() {
        return valorPago;
    }
    public void setValorPago(Double valorPago) {
        this.valorPago = valorPago;
    }
    public String getLivro() {
        return livro;
    }
    public void setLivro(String livro) {
        this.livro = livro;
    }
    public FormaPagamento getPagamento() {
        return pagamento;
    }
    public void setPagamento(FormaPagamento pagamento) {
        this.pagamento = pagamento;
    }
}
