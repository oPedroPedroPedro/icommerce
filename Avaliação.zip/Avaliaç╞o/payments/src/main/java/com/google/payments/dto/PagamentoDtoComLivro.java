package com.google.payments.dto;

import com.google.payments.client.Livro;

public class PagamentoDtoComLivro extends PagamentoDto{
    private Livro livroDetalhes;

    public Livro getLivroDetalhes() {
        return livroDetalhes;
    }

    public void setLivroDetalhes(Livro livroDetalhes) {
        this.livroDetalhes = livroDetalhes;
    }
}
