package com.google.payments.model;

public enum FormaPagamento {

    DINHEIRO("Dinheiro"),
    dinheiro("Dinheiro"),
    DEBITO("Cartão de débito"),
    debito("Cartão de débito"),
    CREDITO("Cartão de crédito"),
    credito("Cartão de crédito"),
    PIX("Pix"),
    pix("Pix"),
    TRANSFERENCIA("Transferência"),
    transferencia("Transferência");

    String descricao;

    private FormaPagamento(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }
}
