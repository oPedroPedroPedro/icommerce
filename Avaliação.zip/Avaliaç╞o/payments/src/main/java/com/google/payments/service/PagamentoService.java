package com.google.payments.service;

import java.util.List;
import com.google.payments.dto.PagamentoDto;
import com.google.payments.dto.PagamentoDtoComLivro;

public interface PagamentoService {
    List <PagamentoDto>obterTodosOsPagamentos();
    PagamentoDtoComLivro obterPorId(String id);
    PagamentoDto cadastrarPagamento(PagamentoDto pagamento);
    void excluirPagamento(String id);
    PagamentoDto alterarPagamento(String id, PagamentoDto pagamento);
}
