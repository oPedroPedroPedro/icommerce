package com.google.payments.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.google.payments.client.Livro;
import com.google.payments.client.LivroFeignClient;
import com.google.payments.dto.PagamentoDto;
import com.google.payments.dto.PagamentoDtoComLivro;
import com.google.payments.model.Pagamento;
import com.google.payments.repository.PagamentoRepository;

@Service
public class PagamentoServiceImpl implements PagamentoService{

    @Autowired
    private PagamentoRepository repository;

    @Autowired
    private LivroFeignClient feignClient;

    private ModelMapper mapper = new ModelMapper();

    @Override
    public List<PagamentoDto> obterTodosOsPagamentos() {
        List<Pagamento> pagamentos = repository.findAll();

        return pagamentos.stream()
            .map(p -> mapper.map(p, PagamentoDto.class)) 
            .collect(Collectors.toList());
    }

    @Override
    public PagamentoDtoComLivro obterPorId(String id) {
        Optional<Pagamento> pagamento = repository.findById(id);

        if (pagamento.isPresent()) {
           
            PagamentoDtoComLivro pagamentoComDetalhes = mapper.map(pagamento.get(), PagamentoDtoComLivro.class);
            Livro livro = feignClient.obterLivroPorId(pagamento.get().getLivro());
            pagamentoComDetalhes.setLivroDetalhes(livro);
            return pagamentoComDetalhes;
        }

        return null;
    }

    @Override
    public PagamentoDto cadastrarPagamento(PagamentoDto pagamento) {
        Pagamento pagamentoSalvar = mapper.map(pagamento, Pagamento.class);
        repository.save(pagamentoSalvar);
        return mapper.map(pagamentoSalvar, PagamentoDto.class);
    }

    @Override
    public void excluirPagamento(String id) {
        repository.deleteById(id);
    }

    @Override
    public PagamentoDto alterarPagamento(String id, PagamentoDto pagamento) {
        Optional<Pagamento>pagamentoBusca = repository.findById(id);

        if (pagamentoBusca.isPresent()) {
            Pagamento pagamentoAlterar = mapper.map(pagamento, Pagamento.class);
            pagamentoAlterar.setId(id);
            pagamentoAlterar = repository.save(pagamentoAlterar);
            return mapper.map(pagamentoAlterar, PagamentoDto.class);            
        }
        return null;
    }
}
