package com.google.payments.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import com.google.payments.model.FormaPagamento;

public class PagamentoDto {
    
    private String id;
    @Positive
    @NotNull(message = "O valor deve ser informado!")
    private Double valorPago;
    @NotBlank(message = "O nome do livro deve ser informado!")
    private String livro;
    @NotNull(message = "A forma de pagamento deve ser informada!")
    private FormaPagamento pagamento;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public Double getValorPago() {
        return valorPago;
    }
    public void setValorPago(Double valorPago) {
        this.valorPago = valorPago;
    }
    public String getLivro() {
        return livro;
    }
    public void setLivro(String livro) {
        this.livro = livro;
    }
    public FormaPagamento getPagamento() {
        return pagamento;
    }
    public void setPagamento(FormaPagamento pagamento) {
        this.pagamento = pagamento;
    }
}
